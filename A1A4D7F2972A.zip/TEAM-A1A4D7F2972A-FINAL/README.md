# <System Architect>
Project Name: System Architect

This is a gamified learning simulation** that my team and I built to teach Systems Analysis & Design** concepts. The game presents a top-down floor plan with 8 rooms, each covering a key chapter (SDLC, Requirements, Use Cases, Domain Modeling, Architecture, Security, UI/UX, and Use Case Realization). Inside each room, you solve interactive puzzles — dragging falling cards into correct zones — to master the material. You earn XP, coins, and stars, unlock rooms sequentially, and ultimately face a "Corrupted Core" boss finale followed by a 25-question certification exam. To run it, simply save the code as an `.html` file (e.g., `system-architect.html`) and open it in any modern browser — no server or installation needed. All progress saves automatically to your browser's local storage.
## Run it quickly
open src/index.html 

## Team
-Team id: A1A4D7F2972A

-Members:
2400008148-Yomna Dvaıdar (Leader)
2300012030-Aqsa Waseem
2500006695-Alla ben ghorbel
2300001825-Amean Mahmoud
2400001615-Huda Hassane
2400007294-Nayroz Sherif Fouad abdallal
2400002481-Mohammed ahmad adelfattah sayed ahmed samaha
2300003288-Mohammed atia ahmed mohammed
2300003746-Zeyad naser mohamed mahmoud
2400000433-Mira Zahra(Coordinator)

-Repository:see Repository.txt