For our final project, my team and I built System Architect — Knowledge Quest HQ, a gamified learning platform that teaches Systems Analysis & Design through an interactive office floor plan with 8 rooms, each covering a key chapter (SDLC, Requirements, Use Cases, Domain Modeling, Use Case Realization, Security, Architecture, and UI/UX). Players earn XP and coins by solving drag-and-drop puzzles, unlock rooms sequentially, and face a final boss and certification exam.

Steps to build and run the game:

1. Planning — We mapped out the 8 chapters to 8 rooms, designed the floor plan layout on a 16×10 grid, and wrote lesson content, puzzles, and exam questions for each topic.

2. Development — We coded the entire game as a single HTML file using vanilla JavaScript (no frameworks), CSS Grid/Flexbox for responsive layout, localStorage for saving player progress, and custom SVG animations for visual feedback.

3. Testing — We opened the file locally in Chrome, Firefox, and Edge to check for bugs, responsiveness, and save functionality across browsers.

4. Hosting — We deployed the game to Netlify by dragging the HTML file into the Netlify dashboard. The live link is:  
http://soft-phoenix-a0b5fc.netlify.app

5. Running the game — You can either click the Netlify link above to play instantly in your browser, or download the HTML file and open it locally — no installation, server, or internet connection is required after download.