# ENVIRONMENT.md

## Development Environment

We built this game on different operating systems depending on team member preference. Some of us used Windows 11, others used macOS Ventura, and a few worked on Ubuntu Linux. Since the game runs in a browser, the OS didn't really matter as long as we could test properly.

For coding, we all used Visual Studio Code because it's lightweight and has great syntax highlighting. We also used Git for version control so we could share code and track changes without overwriting each other's work.

## Runtime Environment

The game doesn't need any special runtime like Node.js or Python. It runs entirely inside a web browser. We tested it on Chrome, Firefox, Edge, and Safari— all recent versions from the past couple of years work fine.



## Tools We Used

Here's what we actually used to build this:

- **HTML5** – For the basic structure of the web page and the game interface.
- **CSS3** – For all the styling, animations, the floor plan layout, and making the game look good on different screen sizes.
- **JavaScript (ES6+)** – This is the core of the game. We used vanilla JavaScript for everything: game logic, puzzle mechanics, saving progress, and handling user input.
- **SVG** – For the icons and some of the animated graphics you see in the game.
- **Google Fonts** – We used two fonts: Fredoka for headings and Quicksand for body text. If there's no internet, the browser just falls back to standard system fonts.
- **LocalStorage API** – This is how the game remembers your progress. Your XP, coins, completed rooms, and exam results all get saved right in your browser.
- **Netlify** – We used Netlify to host the game online. It was as simple as dragging our HTML file into their dashboard.

## No External Dependencies

This is important — we didn't use any frameworks or libraries. No React, no Vue, no jQuery, no Bootstrap. Everything is plain HTML, CSS, and JavaScript. That means you don't need to run `npm install` or any build commands. Just open the file and it works.

## What You Need to Run the Game

To run our game, you just need:

- A modern web browser (Chrome works best, but Firefox and Edge are fine too)
- JavaScript turned on (it's on by default in every browser)
- LocalStorage enabled (also on by default — this is just so your progress saves)
- An internet connection only for the Google Fonts (if you're offline, the game still runs fine, just with different fonts)

